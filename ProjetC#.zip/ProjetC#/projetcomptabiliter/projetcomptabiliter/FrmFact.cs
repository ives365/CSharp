﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
namespace projetcomptabiliter
{
    public partial class FrmFact : Form
    {
          public string cs = ConfigurationManager.ConnectionStrings["garag"].ConnectionString;
        public const int WN_BUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")]

        public static extern int SendMessage(IntPtr hW, int Msg, int param, int Iparam);
        [DllImport("user32.dll")]

        public static extern bool ReleaseCapture();

        public void ConnectionBDD(int idfact)
        {
            try
            {
                SqlConnection con = new SqlConnection(cs);

                con.Open();
                if (con.State == System.Data.ConnectionState.Open)
                {
                    
                    SqlCommand cmd = new SqlCommand("SELECT * FROM factures where idFact = '"+idfact+"' ", con);
                    SqlDataReader rd = cmd.ExecuteReader();
                    if(rd.HasRows)
                    {
                        while(rd.Read())
                        {
                                                        
                            txtMat.Text = rd.GetString(1);
                            textBox2.Text = rd.GetString(2);
                            textBox5.Text = rd.GetString(3);
                            textBox8.Text = rd.GetString(4);
                            textBox10.Text = rd.GetString(10);
                            textBox11.Text = rd.GetString(5);
                            textBox12.Text = rd.GetString(6);
                            textBox4.Text = rd.GetString(7);
                            textBox13.Text = rd.GetString(8);
                            textBox14.Text = rd.GetString(9);
                            textBox9.Text = rd.GetString(12);
                            float n = float.Parse(rd.GetString(9));
                            FctLettre b = new FctLettre();
                            string l = b.converti(Convert.ToDouble(n));
                            // MessageBox.Show();
                            textBox1.Text = l.ToString();
                           
                        }
                    }


                }
                con.Close();

            }
            catch (Exception t)
            {
                MessageBox.Show(t.Message);
            }

        }
        
      
         public FrmFact()
        {
            InitializeComponent();
            

        }


         private void textBox9_TextChanged(object sender, EventArgs e)
         {
             //int num = '';
             //string numString = num.ToString();
             //System.Console.WriteLine(numString);

         }

         private void btnPrint_Click_1(object sender, EventArgs e)
         {
             PrintDialog pdlg = new PrintDialog();
             pdlg.ShowDialog();
         }

         private void panel1_Paint(object sender, PaintEventArgs e)
         {

         }

         private void btnmaximize_Click(object sender, EventArgs e)
         {
             this.WindowState = FormWindowState.Maximized;
         }

         private void btnClose_Click(object sender, EventArgs e)
         {
             Application.Exit();
         }

         private void BtnModifier_Click(object sender, EventArgs e)
         {
             //try
             //{
             //    //SqlConnection con = new SqlConnection(cs);
             //    SqlCommand cmd = new SqlCommand("SELECT * FROM Employes", con);

             //    con.Open();
             //    SqlDataReader sdr = cmd.ExecuteReader();
             //    BindingSource source = new BindingSource();
             //    source.DataSource = sdr;
             //    dataGridView1.DataSource = source;

             //    con.Close();
             //}
             //catch (Exception ex)
             //{
             //    MessageBox.Show(ex.Message);

             //}
         }

         public void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
         {
            // e.Graphics.DrawImage(Impression);
             Bitmap bm = new Bitmap(this.Width, this.Height);
             this.DrawToBitmap(bm, new Rectangle(0, 0, this.Width, this.Height));
             e.Graphics.DrawImage(bm, 0, 0);
         }
         private void btnPrint_Click(object sender, EventArgs e)
         {
             printDocument1.Print();
            printDocument1.Print();

         }

         private void textBox5_TextChanged(object sender, EventArgs e)
         {

         }

         private void textBox8_TextChanged(object sender, EventArgs e)
         {

         }

         private void textBox10_TextChanged(object sender, EventArgs e)
         {

         }

         private void textBox11_TextChanged(object sender, EventArgs e)
         {

         }

         private void textBox12_TextChanged(object sender, EventArgs e)
         {

         }

         private void textBox4_TextChanged(object sender, EventArgs e)
         {

         }

         private void txtMat_TextChanged(object sender, EventArgs e)
         {

         }

         private void Valider_Click(object sender, EventArgs e)
         {
             var idf = Int32.Parse(textFact.Text);
             ConnectionBDD(idf);
            
         }

         private void textFact_TextChanged(object sender, EventArgs e)
         {

         }

         private void textBox2_TextChanged(object sender, EventArgs e)
         {

         }

         private void textBox13_TextChanged(object sender, EventArgs e)
         {

         }

         private void textBox14_TextChanged(object sender, EventArgs e)
         {

         }

         private void textBox9_TextChanged_1(object sender, EventArgs e)
         {

         }

         
        
    }
}
