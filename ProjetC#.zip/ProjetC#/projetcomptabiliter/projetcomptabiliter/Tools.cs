﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace projetcomptabiliter
{
    public partial class Tools : Form
    {
        public string cs = ConfigurationManager.ConnectionStrings["garag"].ConnectionString;
        // public string cst = "Data Source=.;Initial Catalog=garage;Integrated Security=True";
        public const int WN_BUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        public Dictionary<int, string> chiffre_lettre = new Dictionary<int, string>();
        [DllImport("user32.dll")]

        public static extern int SendMessage(IntPtr hW, int Msg, int param, int Iparam);
        [DllImport("user32.dll")]

        public static extern bool ReleaseCapture();

        public Tools()
        {
            InitializeComponent();
            chiffre_lettre.Add(1, "un");
            chiffre_lettre.Add(2, "deux");
            chiffre_lettre.Add(3, "trois");
            chiffre_lettre.Add(4, "quantre");
            chiffre_lettre.Add(5, "cinq");
            chiffre_lettre.Add(6, "six");
            chiffre_lettre.Add(7, "sept");
            chiffre_lettre.Add(8, "huit");
            chiffre_lettre.Add(9, "neuf");
            chiffre_lettre.Add(10, "dix");

            chiffre_lettre.Add(11, "onze");

            chiffre_lettre.Add(12, "douze");
            chiffre_lettre.Add(13, "treize");
            chiffre_lettre.Add(14, "quantoze");
            chiffre_lettre.Add(15, "quinze");
            chiffre_lettre.Add(16, "seize");
            chiffre_lettre.Add(17, "dix-sept");
            chiffre_lettre.Add(18, "dix-huit");
            chiffre_lettre.Add(19, "dix-neuf");
            chiffre_lettre.Add(20, "vingt");
            chiffre_lettre.Add(30, "trente");



            chiffre_lettre.Add(40, "quarante");
            chiffre_lettre.Add(50, "cinquante");
            chiffre_lettre.Add(60, "soixante");
            chiffre_lettre.Add(70, "septante");
            chiffre_lettre.Add(80, "quantre-vingt");

            chiffre_lettre.Add(90, "nonante");
            chiffre_lettre.Add(100, "cent");
            chiffre_lettre.Add(1000, "mille");



        }
        public int Idfact { get; set; }

        public float MontantNet { get; set; }
        public string MontantConvertit { get; set; }


        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        public void VerifierDB(string nomClient, string heure)
        {
            try
            {
                SqlConnection con = new SqlConnection(cs);

                con.Open();
                if (con.State == System.Data.ConnectionState.Open)
                {

                    SqlCommand cmd = new SqlCommand("SELECT idFact FROM factures where nomClient = '" + nomClient + "' AND heure='" + heure + "' ", con);
                    SqlDataReader rd = cmd.ExecuteReader();

                    while (rd.Read())
                    {
                        Idfact = rd.GetInt32(0);
                    }


                }
                con.Close();


            }
            catch (Exception t)
            {
                MessageBox.Show(t.Message);
            }


        }

        public int NumFacture(string nomClient, string heure)
        {
            int numfact = 0;
            try
            {
                SqlConnection con = new SqlConnection(cs);

                con.Open();
                if (con.State == System.Data.ConnectionState.Open)
                {

                    SqlCommand cmd = new SqlCommand("SELECT idFact FROM factures where nomClient = '" + nomClient + "' AND heure='" + heure + "' ", con);
                    SqlDataReader rd = cmd.ExecuteReader();

                    while (rd.Read())
                    {
                        numfact = rd.GetInt32(0);
                    }


                }
                con.Close();


            }
            catch (Exception t)
            {
                MessageBox.Show(t.Message);
            }

            return numfact;

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }


        private void cmbRepare_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbRepare.Text.Equals("Agent de Maitrise"))
            {
                int b = 15;
                TxtPrix.Text = b.ToString();
            }
            else if (cmbRepare.Text.Equals("Agent D'execution"))
            {
                int b = 10;
                TxtPrix.Text = b.ToString();
            }
        }

        private void cmbOrgane_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbOrgane.Text.Equals("Pompe d’inject° 4 cyl"))
            {
                cmbMachine.Items.Clear();
                string b = "Réglage";
                string c = "Banc d’essai ";
                TxtType.Text = b.ToString();
                cmbMachine.Text = c.ToString();
                textBox6.Text = "3";
                cmbMachine.DropDownStyle = ComboBoxStyle.DropDown;
                txtNum.Text = "7";
                var g = 16.32;
                cmbPrix.Text = g.ToString();

            }
            else if (cmbOrgane.Text.Equals("Pompe d’inject°6 cyl"))
            {
                cmbMachine.Items.Clear();
                string b = "Réglage";
                string c = "Banc d’essai";
                TxtType.Text = b.ToString();
                cmbMachine.Text = c.ToString();
                textBox6.Text = "3";
                txtNum.Text = "7";
                var g = 16.32;
                cmbPrix.Text = g.ToString();
            }
            else if (cmbOrgane.Text.Equals("Pompe d’inject° 8 cyl. "))
            {
                cmbMachine.Items.Clear();
                string b = "Réglage";
                string c = "Banc d’essai";
                TxtType.Text = b.ToString();
                cmbMachine.Text = c.ToString();
                textBox6.Text = "3";
                txtNum.Text = "7";
                var g = 16.32;
                cmbPrix.Text = g.ToString();
            }
            else if (cmbOrgane.Text.Equals("Vilebrequin 4 cyl"))
            {
                cmbMachine.Items.Clear();
                string[] tab = { "Rectifieuse", "Pont roulant" };

                string c = "Rectifieuse", d = "Rectification";
                TxtType.Text = d.ToString();
                cmbMachine.Text = c.ToString();
                cmbMachine.Items.Add("Rectifieuse");
                cmbMachine.Items.Add("Pont roulant");
                // for (int i = 0; i < tab.Length; i++) cmbMachine.Items.Add(tab[i]);
                textBox6.Text = "3";
                txtNum.Text = "2";
                var g = 75.89;
                cmbPrix.Text = g.ToString();
            }
            else if (cmbOrgane.Text.Equals("Vilebrequin 6 cyl. "))
            {
                cmbMachine.Items.Clear();
                string[] tab = { "Rectifieuse", "Pont roulant" };

                string c = "Rectifieuse", d = "Rectification";
                TxtType.Text = d.ToString();
                cmbMachine.Text = c.ToString();
                for (int i = 0; i < tab.Length; i++) cmbMachine.Items.Add(tab[i]);
                textBox6.Text = "3";
                txtNum.Text = "2";
                var g = 75.89;
                cmbPrix.Text = g.ToString();
            }
            else if (cmbOrgane.Text.Equals("Bloc moteur 4 cyl"))
            {
                cmbMachine.Items.Clear();
                string[] tab = { "Alésieuse", "Pont roulant", "Honneuse" };
                string d = "Alésage", c = "Pont roulant";
                TxtType.Text = d.ToString();
                cmbMachine.Text = c.ToString();
                for (int i = 0; i < tab.Length; i++) cmbMachine.Items.Add(tab[i]);
                textBox6.Text = "1";
                txtNum.Text = "6";
                var g = 42.36;
                cmbPrix.Text = g.ToString();
            }
            else if (cmbOrgane.Text.Equals("Bloc moteur 6  cyl. "))
            {
                cmbMachine.Items.Clear();
                string[] tab = { "Alésieuse", "Pont roulant", "Honneuse" };
                string d = "Alésage", c = "Pont roulant";
                TxtType.Text = d.ToString();
                cmbMachine.Text = c.ToString();
                for (int i = 0; i < tab.Length; i++) cmbMachine.Items.Add(tab[i]);
                textBox6.Text = "1";
                txtNum.Text = "6";
                var g = 42.36;
                cmbPrix.Text = g.ToString();
            }
            else if (cmbOrgane.Text.Equals("Culasse 4 cylindres "))
            {
                cmbMachine.Items.Clear();
                string d = "Planage";
                string c = "Planeuse";
                TxtType.Text = d.ToString();
                cmbMachine.Text = c.ToString();
                textBox6.Text = "2";
                txtNum.Text = "3";
                var g = 58.46;
                cmbPrix.Text = g.ToString();
            }
            else if (cmbOrgane.Text.Equals("Culasse 6 cylindres "))
            {
                cmbMachine.Items.Clear();
                string[] tab = { "Pont roulant", "Planeuse" };
                string d = "Planage ", c = "Pont roulant";
                TxtType.Text = d.ToString();
                cmbMachine.Text = c.ToString();
                for (int i = 0; i < tab.Length; i++) cmbMachine.Items.Add(tab[i]);
                textBox6.Text = "1";
                txtNum.Text = "6";
                var f = 42.36;
                cmbPrix.Text = f.ToString();
            }
        }

        private void cmbType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbMachine_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMachine.Text.Equals("Alésieuse"))
            {
                float b = 1;
                double c = 89.25;
                txtNum.Text = "1";
                cmbPrix.Text = c.ToString();

            }
            else if (cmbMachine.Text.Equals("Rectifieuse"))
            {
                float b = 2;
                double c = 75.89;
                txtNum.Text = "2";
                cmbPrix.Text = c.ToString();
            }

            else if (cmbMachine.Text.Equals("Planeuse"))
            {
                float b = 3;
                double c = 58.46;
                txtNum.Text = "3";
                cmbPrix.Text = c.ToString();
            }
            else if (cmbMachine.Text.Equals("Honneuse"))
            {
                float b = 4;
                double c = 62.20;
                txtNum.Text = b.ToString();
                cmbPrix.Text = c.ToString();
            }
            else if (cmbMachine.Text.Equals("Presse"))
            {
                float b = 5;
                double c = 12.45;
                txtNum.Text = b.ToString();
                cmbPrix.Text = c.ToString();
            }
            else if (cmbMachine.Text.Equals("Pont roulant"))
            {
                float b = 6;
                double c = 42.36;
                txtNum.Text = "6";
                cmbPrix.Text = c.ToString();
            }
            else if (cmbMachine.Text.Equals("Banc d’essai"))
            {

            }

        }

        private void cmbPrix_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void Conversion()
        {
            /*  if (MontantNet.ToString().Length == 2)
              {
              
              }*/
        }
        private void btnsave_Click(object sender, EventArgs e)
        {

            var frais = 5 * Int32.Parse(textBox5.Text);
            textBox10.Text = frais.ToString() + "$";
            var prixMain = Int32.Parse(TxtPrix.Text) * Int32.Parse(textBox5.Text);
            textBox8.Text = prixMain.ToString() + "$";
            var prixMachine = Convert.ToSingle(cmbPrix.Text) * Int32.Parse(textBox4.Text);


            textBox9.Text = prixMachine.ToString() + "$";
            textBox11.Text = textBox5.Text;
            textBox12.Text = textBox4.Text;
            var tva = ((frais * 16) / 100) + prixMain;
            textBox13.Text = tva.ToString();
            textBox14.Text = (tva + prixMain + frais + prixMachine).ToString() + "$";
            var montant_net = tva + prixMain + frais + prixMachine;

            MontantNet = montant_net;
            // string c = ConfigurationManager.ConnectionStrings["garag"].ConnectionString;
            try
            {
                SqlConnection con = new SqlConnection(cs);

                con.Open();
                if (con.State == System.Data.ConnectionState.Open)
                {
                    if (Idfact == 0)
                    {
                        SqlCommand cmd = new SqlCommand("INSERT INTO factures (nomClient,contact,reparateur,prix_main_oeuvre,mo,heure,prixU,tva,montant,frais_admin,t_oeuvre,t_machine,montant_a_lettre) VALUES ('" + txtMat.Text + "','" + textBox1.Text + "', '" + cmbOrgane.Text + "', '" + prixMain + "','" + textBox5.Text + "', '" + textBox4.Text + "','" + TxtPrix.Text + "','" + tva + "', '" + montant_net + "', '" + frais + "', '" + textBox1.Text + "', '" + prixMachine + "', '" + textBox1.Text + "')", con);
                        SqlDataReader rd = cmd.ExecuteReader();
                        textBox7.Text = NumFacture(txtMat.Text, textBox4.Text).ToString();

                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand("UPDATE factures SET nomClient='" + txtMat.Text + "',contact='" + textBox1.Text + "',reparateur='" + cmbOrgane.Text + "',prix_main_oeuvre='" + prixMain + "',mo='" + textBox5.Text + "',heure='" + textBox4.Text + "',prixU='" + TxtPrix.Text + "',tva='" + tva + "',montant='" + montant_net + "',frais_admin='" + frais + "',t_oeuvre='" + textBox1.Text + "',prixMachine='" + textBox1.Text + "',montant_a_lettre='" + textBox1.Text + "' where idFact='" + Idfact + "'", con);
                        SqlDataReader rd = cmd.ExecuteReader();
                    }


                }
                con.Close();

            }
            catch (Exception t)
            {
                MessageBox.Show(t.Message);
            }

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtPrix_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtType_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void txtMat_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtMat.Text = "";
            textBox1.Text = "";
            textBox6.Text = "";
            textBox4.Text = "";
            textBox4.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            textBox12.Text = "";
            textBox13.Text = "";
            textBox14.Text = "";
            textBox5.Text = "";
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnModifier_Click(object sender, EventArgs e)
        {
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            textBox12.Text = "";
            textBox13.Text = "";
            textBox14.Text = "";
            VerifierDB(txtMat.Text, textBox4.Text);
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void txtNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_Validated(object sender, EventArgs e)
        {
            float init = 0;
            string b = textBox4.Text;
            if (textBox4.Text.Equals(""))
            {
                MessageBox.Show(this, " la valeur du temps machine doit etre saisie ", "error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }
            else
            {
                if (cmbOrgane.Text.Equals("Pompe d’inject° 4 cyl"))
                {
                    if (!(float.Parse(b) >= 1 && float.Parse(b) <= 3))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 1 et 3", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox4.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Pompe d’inject°6 cyl"))
                {
                    if (!(float.Parse(b) >= 1.5 && float.Parse(b) <= 4.5))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 1.5 et 4.5", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox4.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Pompe d’inject° 8 cyl"))
                {
                    if (!(float.Parse(b) >= 2.5 && float.Parse(b) <= 6))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 2.5 et 6", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox4.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Vilebrequin 4 cyl"))
                {
                    if (cmbMachine.Text.Equals("Rectifieuse"))
                    {
                        if (!(float.Parse(b) >= 2 && float.Parse(b) <= 2.5))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 2 et 2.5", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                    else if (cmbMachine.Text.Equals("Pont roulant"))
                    {
                        if (!(float.Parse(b) >= 0.5 && float.Parse(b) <= 1))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 0.5 et 1", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }

                }
                else if (cmbOrgane.Text.Equals("Vilebrequin 6 cyl."))
                {
                    if (cmbMachine.Text.Equals("Rectifieuse"))
                    {
                        if (!(float.Parse(b) >= 3 && float.Parse(b) <= 4))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 3 et 4", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                    else if (cmbMachine.Text.Equals("Pont roulant"))
                    {
                        if (!(float.Parse(b) >= 0.5 && float.Parse(b) <= 1))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 0.5 et 1", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                }
                else if (cmbOrgane.Text.Equals("Bloc moteur 4 cyl"))
                {
                    if (cmbMachine.Text.Equals("Aléseuse"))
                    {
                        if (!(float.Parse(b) >= 2 && float.Parse(b) <= 3))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 2 et 3", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                    else if (cmbMachine.Text.Equals("Pont roulant"))
                    {
                        if (!(float.Parse(b) >= 0.75 && float.Parse(b) <= 1))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 0.75 et 1", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                    else if (cmbMachine.Text.Equals("Honneuse"))
                    {
                        if (!(float.Parse(b) >= 1 && float.Parse(b) <= 1.5))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 1 et 1.5 ", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                }
                else if (cmbOrgane.Text.Equals("Bloc moteur 6  cyl"))
                {
                    if (cmbMachine.Text.Equals("Aléseuse"))
                    {
                        if (!(float.Parse(b) >= 3 && float.Parse(b) <= 5))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 2 et 3", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                    else if (cmbMachine.Text.Equals("Pont roulant"))
                    {
                        if (!(float.Parse(b) >= 0.75 && float.Parse(b) <= 1))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 0.75 et 1", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                    else if (cmbMachine.Text.Equals("Honneuse"))
                    {
                        if (!(float.Parse(b) >= 1 && float.Parse(b) <= 1.5))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 1 et 1.5 ", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                }
                else if (cmbOrgane.Text.Equals("Culasse 4 cylindres"))
                {
                    if (!(float.Parse(b) >= 1 && float.Parse(b) <= 2))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 1 et 3", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox4.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Culasse 6 cylindres"))
                {
                    if (cmbMachine.Text.Equals("Planeuse"))
                    {
                        if (!(float.Parse(b) >= 2 && float.Parse(b) <= 3))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 2 et 3", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                    else if (cmbMachine.Text.Equals("Pont roulant"))
                    {
                        if (!(float.Parse(b) >= 0.5 && float.Parse(b) <= 1))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 0.5 et 1", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                }
                else if (cmbOrgane.Text.Equals("Bloc moteur 4 cyl."))
                {
                    if (cmbMachine.Text.Equals("Aléseuse"))
                    {
                        if (!(float.Parse(b) >= 2 && float.Parse(b) <= 3))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 2 et 3", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                    else if (cmbMachine.Text.Equals("Pont roulant"))
                    {
                        if (!(float.Parse(b) >= 0.75 && float.Parse(b) <= 1))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 0.75 et 1", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                    else if (cmbMachine.Text.Equals("Honneuse"))
                    {
                        if (!(float.Parse(b) >= 1 && float.Parse(b) <= 1.5))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 1 et 1.5 ", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                    else if (cmbMachine.Text.Equals("Presse"))
                    {
                        if (!(float.Parse(b) >= 1 && float.Parse(b) <= 2))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 1 et 2 ", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                }
                else if (cmbOrgane.Text.Equals("Bloc moteur 6  cyl."))
                {
                    if (cmbMachine.Text.Equals("Aléseuse"))
                    {
                        if (!(float.Parse(b) >= 0.75 && float.Parse(b) <= 1))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 0.75 et 1", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                    else if (cmbMachine.Text.Equals("Pont roulant"))
                    {
                        if (!(float.Parse(b) >= 3 && float.Parse(b) <= 5))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 3 et 5", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                    else if (cmbMachine.Text.Equals("Honneuse"))
                    {
                        if (!(float.Parse(b) >= 1 && float.Parse(b) <= 1.5))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 1 et 1.5 ", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                    else if (cmbMachine.Text.Equals("Presse"))
                    {
                        if (!(float.Parse(b) >= 2 && float.Parse(b) <= 3))
                        {
                            MessageBox.Show(this, "la valeur saisi doit etre comprise entre 2 et 3 ", " Machine operationnel", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            textBox4.Text = init.ToString();
                        }
                    }
                }
            }


        }

        private void textBox5_Validated(object sender, EventArgs e)
        {
            float init = 0;
            string b = textBox5.Text;
            if (textBox5.Text.Equals(""))
            {
                MessageBox.Show(this, " la valeur des heures d'utilisation de  machine doit etre saisie ", "error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }
            else
            {
                if (cmbOrgane.Text.Equals("Pompe d’inject° 4 cyl"))
                {
                    if (!(float.Parse(b) >= 1.5 && float.Parse(b) <= 3.5))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 1.5 et 3.5", " temps operationel MO", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox5.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Pompe d’inject°6 cyl"))
                {
                    if (!(float.Parse(b) >= 2 && float.Parse(b) <= 5))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 2 et 5", " temps operationel MO", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox5.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Pompe d’inject° 8 cyl"))
                {
                    if (!(float.Parse(b) >= 3 && float.Parse(b) <= 6.5))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 3 et 6.5", " temps operationel MO", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox5.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Vilebrequin 4 cyl"))
                {
                    if (!(float.Parse(b) >= 3 && float.Parse(b) <= 3.5))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 3 et 3.5", " temps operationel MO", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox5.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Vilebrequin 6 cyl."))
                {
                    if (!(float.Parse(b) >= 3 && float.Parse(b) <= 5))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 3 et 5", " temps operationel MO", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox5.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Bloc moteur 4 cyl"))
                {
                    if (!(float.Parse(b) >= 4.5 && float.Parse(b) <= 6))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 4.5 et 6", " temps operationel MO", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox5.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Bloc moteur 6  cyl"))
                {
                    if (!(float.Parse(b) >= 5 && float.Parse(b) <= 8))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 5 et 8", " temps operationel MO", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox5.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Culasse 4 cylindres "))
                {
                    if (!(float.Parse(b) >= 2 && float.Parse(b) <= 3))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 2 et 3", " temps operationel MO", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox5.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Culasse 6 cylindres"))
                {
                    if (!(float.Parse(b) >= 3 && float.Parse(b) <= 4.5))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 3 et 4.5", " temps operationel MO", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox5.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Bloc moteur 4 cyl."))
                {
                    if (!(float.Parse(b) >= 5 && float.Parse(b) <= 8))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 5 et 8", " temps operationel MO", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox5.Text = init.ToString();
                    }
                }
                else if (cmbOrgane.Text.Equals("Bloc moteur 6  cyl."))
                {
                    if (!(float.Parse(b) >= 7 && float.Parse(b) <= 12))
                    {
                        MessageBox.Show(this, "la valeur saisi doit etre comprise entre 7 et 12 ", " temps operationel MO", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        textBox5.Text = init.ToString();
                    }
                }
            }
        }

    } 
}
