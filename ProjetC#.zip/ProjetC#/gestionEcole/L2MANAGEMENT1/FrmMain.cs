﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L2MANAGEMENT1
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
            System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
            gp.AddEllipse(0, 0, pictureBox1.Width - 2, pictureBox1.Height - 2);
            Region rg = new Region(gp);
            pictureBox1.Region = rg;
        }
        

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string name = "Admin"; // ce code permet de tester le username et le password
            string pwd = "123456";
            if (txtUsername.Text == name && txtPassword.Text == pwd)
            {
                FrmAccueil fa = new FrmAccueil();
                this.Hide();
                fa.Show();
            }
            else
            {
                MessageBox.Show("Wrong username or password", "message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      

        
    }
}
