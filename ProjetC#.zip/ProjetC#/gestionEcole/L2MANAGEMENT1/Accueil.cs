﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L2MANAGEMENT1
{
    public partial class Accueil : Form
    {
        public const int WN_BUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hW, int Msg, int param, int Iparam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        public Accueil()
        {
           
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            //Application.Exit();

        } 
        private void panelTop_MouseDown(object sender, MouseEventArgs e)
        {
            //
            ReleaseCapture();
            SendMessage(Handle, WN_BUTTONDOWN, HT_CAPTION, 0);

        }

        private void Accueil_Load(object sender, EventArgs e)
        {
            
            this.MaximizedBounds = Screen.FromHandle(this.Handle).WorkingArea;
            this.WindowState = FormWindowState.Maximized;

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(MENU.UcHome.Instance))
            {
                MainPanel.Controls.Add(MENU.UcHome.Instance);
                MENU.UcHome.Instance.Dock = DockStyle.Fill;
                MENU.UcHome.Instance.BringToFront();


            }
            else
            {
                MENU.UcHome.Instance.BringToFront();

            }

        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnMaximize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void btnEtudiant_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(MENU.UcEtudiant.Instance))
            {
                MainPanel.Controls.Add(MENU.UcEtudiant.Instance);
                MENU.UcEtudiant.Instance.Dock = DockStyle.Fill;
                MENU.UcEtudiant.Instance.BringToFront();


            }
            else
            {
                MENU.UcEtudiant.Instance.BringToFront();

            }

        }

        private void eTUDIANTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(MENU.UcHome.Instance))
            {
                MainPanel.Controls.Add(MENU.UcHome.Instance);
                MENU.UcHome.Instance.Dock = DockStyle.Fill;
                MENU.UcHome.Instance.BringToFront();


            }
            else
            {
                MENU.UcHome.Instance.BringToFront();

            }

        }

        private void eTUDIANTToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(MENU.UcEtudiant.Instance))
            {
                MainPanel.Controls.Add(MENU.UcEtudiant.Instance);
                MENU.UcEtudiant.Instance.Dock = DockStyle.Fill;
                MENU.UcEtudiant.Instance.BringToFront();


            }
            else
            {
                MENU.UcEtudiant.Instance.BringToFront();

            }

        }

        private void btnCours_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(MENU.UcCours.Instance))
            {
                MainPanel.Controls.Add(MENU.UcCours.Instance);
                MENU.UcCours.Instance.Dock = DockStyle.Fill;
                MENU.UcCours.Instance.BringToFront();


            }
            else
            {
                MENU.UcCours.Instance.BringToFront();

            }

        }

        private void cOURSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(MENU.UcCours.Instance))
            {
                MainPanel.Controls.Add(MENU.UcCours.Instance);
                MENU.UcCours.Instance.Dock = DockStyle.Fill;
                MENU.UcCours.Instance.BringToFront();


            }
            else
            {
                MENU.UcCours.Instance.BringToFront();

            }

        }

        private void btnPoint_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(MENU.UcCote.Instance))
            {
                MainPanel.Controls.Add(MENU.UcCote.Instance);
                MENU.UcCote.Instance.Dock = DockStyle.Fill;
                MENU.UcCote.Instance.BringToFront();


            }
            else
            {
                MENU.UcCote.Instance.BringToFront();

            }

        }

        private void pOINTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(MENU.UcCote.Instance))
            {
                MainPanel.Controls.Add(MENU.UcCote.Instance);
                MENU.UcCote.Instance.Dock = DockStyle.Fill;
                MENU.UcCote.Instance.BringToFront();


            }
            else
            {
                MENU.UcCote.Instance.BringToFront();

            }

        }

        private void btnHoraire_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(MENU.UcHoraire.Instance))
            {
                MainPanel.Controls.Add(MENU.UcHoraire.Instance);
                MENU.UcHoraire.Instance.Dock = DockStyle.Fill;
                MENU.UcHoraire.Instance.BringToFront();


            }
            else
            {
                MENU.UcHoraire.Instance.BringToFront();

            }

        }

        private void hORAIREToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(MENU.UcHoraire.Instance))
            {
                MainPanel.Controls.Add(MENU.UcHoraire.Instance);
                MENU.UcHoraire.Instance.Dock = DockStyle.Fill;
                MENU.UcHoraire.Instance.BringToFront();


            }
            else
            {
                MENU.UcHoraire.Instance.BringToFront();

            }

        }

        private void btnResultat_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(MENU.UcResultat.Instance))
            {
                MainPanel.Controls.Add(MENU.UcResultat.Instance);
                MENU.UcResultat.Instance.Dock = DockStyle.Fill;
                MENU.UcResultat.Instance.BringToFront();


            }
            else
            {
                MENU.UcResultat.Instance.BringToFront();

            }

        }

        private void rESULTATToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(MENU.UcResultat.Instance))
            {
                MainPanel.Controls.Add(MENU.UcResultat.Instance);
                MENU.UcResultat.Instance.Dock = DockStyle.Fill;
                MENU.UcResultat.Instance.BringToFront();


            }
            else
            {
                MENU.UcResultat.Instance.BringToFront();

            }

        }

        
      
        

        

        
    }
}
