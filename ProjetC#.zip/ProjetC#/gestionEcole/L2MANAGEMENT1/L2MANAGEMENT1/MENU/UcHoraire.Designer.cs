﻿namespace L2MANAGEMENT1.MENU
{
    partial class UcHoraire
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtHoraireSemaine = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtHeures = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSamedi = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtVendredi = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtJeudi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMercredi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMardi = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLundi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(171)))), ((int)(((byte)(237)))));
            this.panel1.Controls.Add(this.txtHoraireSemaine);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.txtHeures);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txtSamedi);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.txtVendredi);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtJeudi);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txtMercredi);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtMardi);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtLundi);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnLoad);
            this.panel1.Controls.Add(this.btnDelete);
            this.panel1.Controls.Add(this.btnUpdate);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.btnSearch);
            this.panel1.Controls.Add(this.txtSearch);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(826, 345);
            this.panel1.TabIndex = 0;
            // 
            // txtHoraireSemaine
            // 
            this.txtHoraireSemaine.Location = new System.Drawing.Point(160, 74);
            this.txtHoraireSemaine.Name = "txtHoraireSemaine";
            this.txtHoraireSemaine.Size = new System.Drawing.Size(200, 20);
            this.txtHoraireSemaine.TabIndex = 75;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(51, 77);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 13);
            this.label9.TabIndex = 74;
            this.label9.Text = "Horaire de la semaine";
            // 
            // txtHeures
            // 
            this.txtHeures.Location = new System.Drawing.Point(160, 100);
            this.txtHeures.Name = "txtHeures";
            this.txtHeures.Size = new System.Drawing.Size(200, 20);
            this.txtHeures.TabIndex = 73;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(51, 103);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 13);
            this.label8.TabIndex = 72;
            this.label8.Text = "Heures";
            // 
            // txtSamedi
            // 
            this.txtSamedi.Location = new System.Drawing.Point(160, 256);
            this.txtSamedi.Name = "txtSamedi";
            this.txtSamedi.Size = new System.Drawing.Size(200, 20);
            this.txtSamedi.TabIndex = 71;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(51, 259);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 70;
            this.label7.Text = "Samedi";
            // 
            // txtVendredi
            // 
            this.txtVendredi.Location = new System.Drawing.Point(160, 230);
            this.txtVendredi.Name = "txtVendredi";
            this.txtVendredi.Size = new System.Drawing.Size(200, 20);
            this.txtVendredi.TabIndex = 69;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(51, 233);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 68;
            this.label6.Text = "Vendredi";
            // 
            // txtJeudi
            // 
            this.txtJeudi.Location = new System.Drawing.Point(160, 204);
            this.txtJeudi.Name = "txtJeudi";
            this.txtJeudi.Size = new System.Drawing.Size(200, 20);
            this.txtJeudi.TabIndex = 67;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(51, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 66;
            this.label5.Text = "Jeudi";
            // 
            // txtMercredi
            // 
            this.txtMercredi.Location = new System.Drawing.Point(160, 178);
            this.txtMercredi.Name = "txtMercredi";
            this.txtMercredi.Size = new System.Drawing.Size(200, 20);
            this.txtMercredi.TabIndex = 65;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 64;
            this.label3.Text = "Mercredi";
            // 
            // txtMardi
            // 
            this.txtMardi.Location = new System.Drawing.Point(160, 152);
            this.txtMardi.Name = "txtMardi";
            this.txtMardi.Size = new System.Drawing.Size(200, 20);
            this.txtMardi.TabIndex = 63;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 62;
            this.label2.Text = "Mardi";
            // 
            // txtLundi
            // 
            this.txtLundi.Location = new System.Drawing.Point(160, 126);
            this.txtLundi.Name = "txtLundi";
            this.txtLundi.Size = new System.Drawing.Size(200, 20);
            this.txtLundi.TabIndex = 61;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 129);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 60;
            this.label1.Text = "Lundi";
            // 
            // btnLoad
            // 
            this.btnLoad.Image = global::L2MANAGEMENT1.Properties.Resources.Typicons_e017_0__32;
            this.btnLoad.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoad.Location = new System.Drawing.Point(515, 290);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(75, 37);
            this.btnLoad.TabIndex = 59;
            this.btnLoad.Text = "       Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Image = global::L2MANAGEMENT1.Properties.Resources.themify_e605_0__32;
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(416, 290);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 37);
            this.btnDelete.TabIndex = 58;
            this.btnDelete.Text = "        Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Image = global::L2MANAGEMENT1.Properties.Resources.Material_Icons_e2c4_0__32;
            this.btnUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdate.Location = new System.Drawing.Point(322, 290);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 37);
            this.btnUpdate.TabIndex = 57;
            this.btnUpdate.Text = "      Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnSave
            // 
            this.btnSave.Image = global::L2MANAGEMENT1.Properties.Resources.Typicons_e075_0__32;
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(225, 290);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 37);
            this.btnSave.TabIndex = 56;
            this.btnSave.Text = "      Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(506, 26);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 14;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(326, 26);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(165, 20);
            this.txtSearch.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(245, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Recherche";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 345);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(826, 159);
            this.dataGridView1.TabIndex = 1;
            // 
            // UcHoraire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Name = "UcHoraire";
            this.Size = new System.Drawing.Size(826, 504);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtSamedi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtVendredi;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtJeudi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMercredi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMardi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLundi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtHoraireSemaine;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtHeures;
        private System.Windows.Forms.Label label8;
    }
}
