﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L2MANAGEMENT1.MENU
{
    public partial class UcHome : UserControl
    {
        private static UcHome _instance;
        public static UcHome Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new UcHome();
                return _instance;
            }
        }

        public UcHome()
        {
            InitializeComponent();

            //System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
            //gp.AddEllipse(0, 0, pictureBox1.Width - 2, pictureBox1.Height - 2);
            //Region rg = new Region(gp);
            //pictureBox1.Region = rg; 
        }
    }
}
