﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace L2MANAGEMENT1.MENU
{
    public partial class UcCote : UserControl
    {
        private static UcCote _instance;
        public static UcCote Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new UcCote();
                return _instance;
            }
        }
        public UcCote()
        {
            InitializeComponent();
        }
        string cs = ConfigurationManager.ConnectionStrings["L2MSI"].ConnectionString;

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(txtMatricule.Text) || string.IsNullOrWhiteSpace(txtCoursID.Text) ) // ce code verifie si ces champs sont vides(rien) 
            {
                MessageBox.Show(this, "you have to fill all the required textboxes before saving", "warning", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning); // ce code nous affiche le message d'erreur disant que les champs sont vides
            }
            else // code permet de sauvegarder l'image en binaire dans notre base de données
            { // ce code permet de sauvegarder dans la base de donnée
                
                //ce code permet d'eteblir la connexion

                SqlConnection con = new SqlConnection(cs);
                SqlCommand cmd = new SqlCommand("INSERT INTO Point (Matricule, CoursID, Point) VALUES('" + this.txtMatricule.Text + "','" + this.txtCoursID.Text + "', '" + this.txtPoints.Text +  "')", con); // ici on reprend les champs de la table employes

                SqlDataReader sdr;
                try
                {
                    con.Open();
                
                    sdr = cmd.ExecuteReader();

                    MessageBox.Show(this, "Save successfully", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    while(sdr.Read())
                    {

                    }
                    con.Close();

                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message); // ce code affiche l'erreur et l'endroit ou elle se trouve
                }
            

        }
    }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // ce ligne de code nous permet de faire la mise à jourde la table employes
                SqlConnection con = new SqlConnection(cs);
                string query = "UPDATE Point SET Matricule = '" + txtMatricule.Text + "', CoursID = '" + txtCoursID.Text + "', Point= '" + txtPoints.Text +  "' WHERE Matricule = '" +txtSearch.Text+"'"; // chercher dans la table employes le matricule qui est comme
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
             
                MessageBox.Show(this, txtMatricule.Text + " " + txtCoursID.Text + "has been successfully updated", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();

            }
            catch (Exception ex)
            {
                
                MessageBox.Show(ex.Message);
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(cs);
                SqlCommand cmd = new SqlCommand("SELECT Etudiant.N°, Etudiant.MATRICULE,Etudiant.NOM,Etudiant.POSTNOM, Point.Point FROM Etudiant LEFT JOIN Point ON Etudiant.N° = Point.IDEtudiant", con);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                BindingSource source = new BindingSource();
                source.DataSource = sdr;
                dataGridView1.DataSource = source;
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message); // ce code permet d'afficher les messages
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            string query = string.Format("SELECT Etudiant$.Matricule,Etudiant.Nom,Etudiant.PostNom,Cote.Points, Cours.CoursID FROM Etudiant$ inner JOIN Cote ON Etudiant$.Matricule = Cote.Matricule inner Cours on CoursID = Cote.CoursID WHERE Etudiant$.MATRICULE LIKE'%{0}%'", txtSearch.Text); // chercher dans la table employes le matricule qui est comme
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader sdr;
            try
            {
                con.Open();
                sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    if (string.IsNullOrWhiteSpace(txtSearch.Text))
                    {
                        MessageBox.Show(this, "please type reglements before searching", "Warning", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        txtMatricule.Text = sdr["Matricule"].ToString();
                        txtCoursID.Text = sdr["CoursID"].ToString();
                        txtPoints.Text = sdr["Point"].ToString();
                        
                        
                        

                        // code permet d'afficher juste la photo

                    }
                }

                con.Close();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
}
}
