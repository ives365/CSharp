﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace L2MANAGEMENT1.MENU
{
    public partial class UcCours : UserControl
    {
        private static UcCours _instance;
        public static UcCours Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new UcCours();
                return _instance;
            }
        }
        public UcCours()
        {
            InitializeComponent();
        }
        string cs = ConfigurationManager.ConnectionStrings["L2MSI"].ConnectionString;

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(txtIntitule.Text) || string.IsNullOrWhiteSpace(txtNomProfesseur.Text) ) // ce code verifie si ces champs sont vides(rien) 
            {
                MessageBox.Show(this, "you have to fill all the required textboxes before saving", "warning", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning); // ce code nous affiche le message d'erreur disant que les champs sont vides
            }
            else // code permet de sauvegarder l'image en binaire dans notre base de données
            { // ce code permet de sauvegarder dans la base de donnée
                
                //ce code permet d'eteblir la connexion

                SqlConnection con = new SqlConnection(cs);
                SqlCommand cmd = new SqlCommand("INSERT INTO Cours (Intitule,NomProfesseur,VolumeHoraire,Ponderation) VALUES('" + this.txtIntitule.Text + "','" + this.txtNomProfesseur.Text + "', '" + this.txtVolumeHoraire.Text + "','" + this.txtPonderation.Text + "')", con); // ici on reprend les champs de la table employes

                SqlDataReader sdr;
                try
                {
                    con.Open();
                
                    sdr = cmd.ExecuteReader();

                    MessageBox.Show(this, "Save successfully", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    while(sdr.Read())
                    {

                    }
                    con.Close();

                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message); // ce code affiche l'erreur et l'endroit ou elle se trouve
                }
            
        } 
             }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // ce ligne de code nous permet de faire la mise à jourde la table employes
                SqlConnection con = new SqlConnection(cs);
                string query = "UPDATE Cours SET Intitule = '" + txtIntitule.Text + "', NomProfesseur = '" + txtNomProfesseur.Text + "', VolumeHoraire= '" + txtVolumeHoraire.Text + "', Ponderation='" +txtPonderation.Text +  "' WHERE Intitule = '" +txtSearch.Text+"'"; // chercher dans la table employes le matricule qui est comme
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
             
                MessageBox.Show(this, txtIntitule.Text + " " + txtNomProfesseur.Text + "has been successfully updated", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();

            }
            catch (Exception ex)
            {
                
                MessageBox.Show(ex.Message);
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(cs);
                SqlCommand cmd = new SqlCommand("SELECT * FROM Cours", con);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                BindingSource source = new BindingSource();
                source.DataSource = sdr;
                dataGridView1.DataSource = source;
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message); // ce code permet d'afficher les messages
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            string query = string.Format("SELECT * FROM Cours WHERE Intitule LIKE'%{0}%'", txtSearch.Text); // chercher dans la table employes le matricule qui est comme
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader sdr;
            try
            {
                con.Open();
                sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    if (string.IsNullOrWhiteSpace(txtSearch.Text))
                    {
                        MessageBox.Show(this, "please type reglements before searching", "Warning", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        txtIntitule.Text = sdr["Intitule"].ToString();
                        txtNomProfesseur.Text = sdr["NomProfesseur"].ToString();
                        txtVolumeHoraire.Text = sdr["VolumeHoraire"].ToString();
                        txtPonderation.Text = sdr["Ponderation"].ToString();
                        
                        

                        // code permet d'afficher juste la photo

                    }
                }

                con.Close();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        
        } 
         }


        

        

        

        
    

