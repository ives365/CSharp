﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace L2MANAGEMENT1.MENU
{
    public partial class UcEtudiant : UserControl
    {
        private static UcEtudiant _instance;
        public static UcEtudiant Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new UcEtudiant();
                return _instance;
            }
        }
        public UcEtudiant()
        {
            InitializeComponent();
        }
        string cs = ConfigurationManager.ConnectionStrings["L2MSI"].ConnectionString;

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(txtMatricule.Text) || string.IsNullOrWhiteSpace(txtNom.Text) || string.IsNullOrWhiteSpace(txtPostNom.Text) ) // ce code verifie si ces champs sont vides(rien) 
            {
                MessageBox.Show(this, "you have to fill all the required textboxes before saving", "warning", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning); // ce code nous affiche le message d'erreur disant que les champs sont vides
            }
            else // code permet de sauvegarder l'image en binaire dans notre base de données
            { // ce code permet de sauvegarder dans la base de donnée
                
                //ce code permet d'eteblir la connexion

                SqlConnection con = new SqlConnection(cs);
                SqlCommand cmd = new SqlCommand("INSERT INTO Etudiant$ (Matricule, Nom, PostNom,Prenom, Genre, Telephone, AdresseElectronique,AdresseDomicile,DateNaissance, LieuNaissance, Nationalite,Filiere,Institution,Promotion) VALUES('" + this.txtMatricule.Text + "','" + this.txtNom.Text + "', '" + this.txtPostNom.Text + "','" + this.txtPrenom.Text + "' ,'" + this.cmbGenre.Text+ "','" + this.txtTelephone.Text + "','" + this.txtAdresseElectronique.Text + "','" + this.txtAdresseDomicile.Text + "','" + this.dtDOB.MinDate + "','" + this.txtLieuNaissance.Text + "','" + this.txtNationalite.Text + "','" + this.txtFiliere.Text + "','" + this.txtInstitution.Text + "','" + this.txtPromotion.Text + "')", con); // ici on reprend les champs de la table employes

                SqlDataReader sdr;
                try
                {
                    con.Open();
                
                    sdr = cmd.ExecuteReader();

                    MessageBox.Show(this, "Save successfully", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    while(sdr.Read())
                    {

                    }
                    con.Close();

                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message); // ce code affiche l'erreur et l'endroit ou elle se trouve
                }
            
        } 

        

       

        
      
    }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // ce ligne de code nous permet de faire la mise à jourde la table employes
                SqlConnection con = new SqlConnection(cs);
                string query = "UPDATE Etudiant$ SET Matricule = '" + txtMatricule.Text + "', Nom = '" + txtNom.Text + "', PostNom= '" + txtPostNom.Text + "', Prenom= '" + txtPrenom.Text + "', Genre='" + cmbGenre.Text +  "', Telephone='" + txtTelephone.Text +  "' , AdresseElectronique='" + txtAdresseElectronique.Text + "' , AdresseDomicile='" + txtAdresseDomicile.Text +  "' , DateNaissance='" + dtDOB.MinDate +  "' , LieuNaissance='" + txtLieuNaissance.Text +  "' , Nationalite='" + txtNationalite.Text +"' , Filiere='" + txtFiliere.Text +  "' , Institution='" + txtInstitution.Text +  "' , Promotion='" + txtPromotion.Text +  "'WHERE Matricule = '" +txtSearch.Text+"'"; // chercher dans la table employes le matricule qui est comme
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
             
                MessageBox.Show(this, txtMatricule.Text + " " + txtNom.Text + " " + txtPostNom.Text +"has been successfully updated", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();

            }
            catch (Exception ex)
            {
                
                MessageBox.Show(ex.Message);
            }
        
        }
            
        

        private void btnLoad_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(cs);
                SqlCommand cmd = new SqlCommand("SELECT * FROM Etudiant$", con);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                BindingSource source = new BindingSource();
                source.DataSource = sdr;
                dataGridView1.DataSource = source;
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message); // ce code permet d'afficher les messages
            }

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            string query = string.Format("SELECT * FROM Etudiant$ WHERE Matricule LIKE'%{0}%'", txtSearch.Text); // chercher dans la table employes le matricule qui est comme
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader sdr;
            try
            {
                con.Open();
                sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    if (string.IsNullOrWhiteSpace(txtSearch.Text))
                    {
                        MessageBox.Show(this, "please type reglements before searching", "Warning", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        txtMatricule.Text = sdr["Matricule"].ToString();
                        txtNom.Text = sdr["Nom"].ToString();
                        txtPostNom.Text = sdr["PostNom"].ToString();
                        txtPrenom.Text = sdr["Prenom"].ToString();
                        cmbGenre.Text = sdr["Genre"].ToString();
                        txtTelephone.Text = sdr["Telephone"].ToString();
                        txtAdresseElectronique.Text = sdr["AdresseElectronique"].ToString();
                        txtAdresseDomicile.Text = sdr["ZdresseDomicile"].ToString();
                        txtNationalite.Text = sdr["Nationalite"].ToString();
                        txtFiliere.Text = sdr["Filiere"].ToString();
                        txtInstitution.Text = sdr["Institution"].ToString();
                        txtPromotion.Text = sdr["Promotion"].ToString();



                        // code permet d'afficher juste la photo

                    }
                }

                con.Close();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
}
}
