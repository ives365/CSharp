﻿namespace L2MANAGEMENT1
{
    partial class Accueil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnMaximize = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hOMEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eTUDIANTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eTUDIANTToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cOURSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pOINTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hORAIREToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rESULTATToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MainPanel = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnCours = new System.Windows.Forms.Button();
            this.btnResultat = new System.Windows.Forms.Button();
            this.btnHoraire = new System.Windows.Forms.Button();
            this.btnEtudiant = new System.Windows.Forms.Button();
            this.btnPoint = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.MainPanel.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnMinimize
            // 
            this.btnMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimize.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.Location = new System.Drawing.Point(593, 6);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(42, 30);
            this.btnMinimize.TabIndex = 2;
            this.btnMinimize.Text = "-";
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Location = new System.Drawing.Point(689, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(42, 30);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "X";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnMaximize
            // 
            this.btnMaximize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaximize.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnMaximize.FlatAppearance.BorderSize = 0;
            this.btnMaximize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaximize.Location = new System.Drawing.Point(641, 6);
            this.btnMaximize.Name = "btnMaximize";
            this.btnMaximize.Size = new System.Drawing.Size(42, 30);
            this.btnMaximize.TabIndex = 1;
            this.btnMaximize.Text = "[]";
            this.btnMaximize.UseVisualStyleBackColor = false;
            this.btnMaximize.Click += new System.EventHandler(this.btnMaximize_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hOMEToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 378);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(748, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hOMEToolStripMenuItem
            // 
            this.hOMEToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(171)))), ((int)(((byte)(237)))));
            this.hOMEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eTUDIANTToolStripMenuItem,
            this.eTUDIANTToolStripMenuItem1,
            this.cOURSToolStripMenuItem,
            this.pOINTToolStripMenuItem,
            this.hORAIREToolStripMenuItem,
            this.rESULTATToolStripMenuItem});
            this.hOMEToolStripMenuItem.Name = "hOMEToolStripMenuItem";
            this.hOMEToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.hOMEToolStripMenuItem.Text = "MENU";
            // 
            // eTUDIANTToolStripMenuItem
            // 
            this.eTUDIANTToolStripMenuItem.Name = "eTUDIANTToolStripMenuItem";
            this.eTUDIANTToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.eTUDIANTToolStripMenuItem.Text = "HOME";
            this.eTUDIANTToolStripMenuItem.Click += new System.EventHandler(this.eTUDIANTToolStripMenuItem_Click);
            // 
            // eTUDIANTToolStripMenuItem1
            // 
            this.eTUDIANTToolStripMenuItem1.Name = "eTUDIANTToolStripMenuItem1";
            this.eTUDIANTToolStripMenuItem1.Size = new System.Drawing.Size(128, 22);
            this.eTUDIANTToolStripMenuItem1.Text = "ETUDIANT";
            this.eTUDIANTToolStripMenuItem1.Click += new System.EventHandler(this.eTUDIANTToolStripMenuItem1_Click);
            // 
            // cOURSToolStripMenuItem
            // 
            this.cOURSToolStripMenuItem.Name = "cOURSToolStripMenuItem";
            this.cOURSToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.cOURSToolStripMenuItem.Text = "COURS";
            this.cOURSToolStripMenuItem.Click += new System.EventHandler(this.cOURSToolStripMenuItem_Click);
            // 
            // pOINTToolStripMenuItem
            // 
            this.pOINTToolStripMenuItem.Name = "pOINTToolStripMenuItem";
            this.pOINTToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.pOINTToolStripMenuItem.Text = "POINT";
            this.pOINTToolStripMenuItem.Click += new System.EventHandler(this.pOINTToolStripMenuItem_Click);
            // 
            // hORAIREToolStripMenuItem
            // 
            this.hORAIREToolStripMenuItem.Name = "hORAIREToolStripMenuItem";
            this.hORAIREToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.hORAIREToolStripMenuItem.Text = "HORAIRE";
            this.hORAIREToolStripMenuItem.Click += new System.EventHandler(this.hORAIREToolStripMenuItem_Click);
            // 
            // rESULTATToolStripMenuItem
            // 
            this.rESULTATToolStripMenuItem.Name = "rESULTATToolStripMenuItem";
            this.rESULTATToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.rESULTATToolStripMenuItem.Text = "RESULTAT";
            this.rESULTATToolStripMenuItem.Click += new System.EventHandler(this.rESULTATToolStripMenuItem_Click);
            // 
            // MainPanel
            // 
            this.MainPanel.Controls.Add(this.panel7);
            this.MainPanel.Controls.Add(this.menuStrip1);
            this.MainPanel.Location = new System.Drawing.Point(164, 0);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(748, 402);
            this.MainPanel.TabIndex = 1;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(171)))), ((int)(((byte)(237)))));
            this.panel7.Controls.Add(this.btnMaximize);
            this.panel7.Controls.Add(this.btnMinimize);
            this.panel7.Controls.Add(this.btnClose);
            this.panel7.Controls.Add(this.btnCours);
            this.panel7.Controls.Add(this.btnResultat);
            this.panel7.Controls.Add(this.btnHoraire);
            this.panel7.Controls.Add(this.btnEtudiant);
            this.panel7.Controls.Add(this.btnPoint);
            this.panel7.Controls.Add(this.btnHome);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Enabled = false;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(748, 100);
            this.panel7.TabIndex = 1;
            // 
            // btnCours
            // 
            this.btnCours.Image = global::L2MANAGEMENT1.Properties.Resources.Iconic_e01f_0__32;
            this.btnCours.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCours.Location = new System.Drawing.Point(306, 54);
            this.btnCours.Name = "btnCours";
            this.btnCours.Size = new System.Drawing.Size(99, 33);
            this.btnCours.TabIndex = 5;
            this.btnCours.Text = "     Cours";
            this.btnCours.UseVisualStyleBackColor = true;
            this.btnCours.Click += new System.EventHandler(this.btnCours_Click);
            // 
            // btnResultat
            // 
            this.btnResultat.Image = global::L2MANAGEMENT1.Properties.Resources.linecons_e024_0__32;
            this.btnResultat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnResultat.Location = new System.Drawing.Point(642, 54);
            this.btnResultat.Name = "btnResultat";
            this.btnResultat.Size = new System.Drawing.Size(99, 33);
            this.btnResultat.TabIndex = 3;
            this.btnResultat.Text = "      Resultat";
            this.btnResultat.UseVisualStyleBackColor = true;
            this.btnResultat.Click += new System.EventHandler(this.btnResultat_Click);
            // 
            // btnHoraire
            // 
            this.btnHoraire.Image = global::L2MANAGEMENT1.Properties.Resources.FontAwesome_f073_0__32;
            this.btnHoraire.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHoraire.Location = new System.Drawing.Point(530, 54);
            this.btnHoraire.Name = "btnHoraire";
            this.btnHoraire.Size = new System.Drawing.Size(99, 33);
            this.btnHoraire.TabIndex = 3;
            this.btnHoraire.Text = "      Horaire";
            this.btnHoraire.UseVisualStyleBackColor = true;
            this.btnHoraire.Click += new System.EventHandler(this.btnHoraire_Click);
            // 
            // btnEtudiant
            // 
            this.btnEtudiant.Image = global::L2MANAGEMENT1.Properties.Resources.Entypo_d83d_0__32;
            this.btnEtudiant.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEtudiant.Location = new System.Drawing.Point(194, 54);
            this.btnEtudiant.Name = "btnEtudiant";
            this.btnEtudiant.Size = new System.Drawing.Size(99, 33);
            this.btnEtudiant.TabIndex = 3;
            this.btnEtudiant.Text = "      Etudiant";
            this.btnEtudiant.UseVisualStyleBackColor = true;
            this.btnEtudiant.Click += new System.EventHandler(this.btnEtudiant_Click);
            // 
            // btnPoint
            // 
            this.btnPoint.Image = global::L2MANAGEMENT1.Properties.Resources.Material_Icons_e22b_0__32;
            this.btnPoint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPoint.Location = new System.Drawing.Point(418, 54);
            this.btnPoint.Name = "btnPoint";
            this.btnPoint.Size = new System.Drawing.Size(99, 33);
            this.btnPoint.TabIndex = 3;
            this.btnPoint.Text = "     Point";
            this.btnPoint.UseVisualStyleBackColor = true;
            this.btnPoint.Click += new System.EventHandler(this.btnPoint_Click);
            // 
            // btnHome
            // 
            this.btnHome.Image = global::L2MANAGEMENT1.Properties.Resources.FontAwesome_f015_32;
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(82, 54);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(99, 33);
            this.btnHome.TabIndex = 1;
            this.btnHome.Text = "     Home";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // FrmManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(992, 402);
            this.Controls.Add(this.MainPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmManagement";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.Load += new System.EventHandler(this.Accueil_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.MainPanel.ResumeLayout(false);
            this.MainPanel.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnResultat;
        private System.Windows.Forms.Button btnHoraire;
        private System.Windows.Forms.Button btnPoint;
        private System.Windows.Forms.Button btnCours;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnEtudiant;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnMaximize;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hOMEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eTUDIANTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eTUDIANTToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cOURSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pOINTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hORAIREToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rESULTATToolStripMenuItem;
        private System.Windows.Forms.Panel MainPanel;
        private System.Windows.Forms.Panel panel7;
    }
}