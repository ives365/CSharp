namespace LibraryManager.Models
{
    public class Avis
    {
        private string _body;
        private string _title;

        public Avis(string title, string body)
        {
            _title = title;
            _body = body;
        }
    }
}
