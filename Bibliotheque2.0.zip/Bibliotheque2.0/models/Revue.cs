namespace LibraryManager.Models
{
    class Revue : Document
    {
        public Revue(int numeroEnregistrement, 
            string titre, 
            uint mois, 
            uint annee) : base(numeroEnregistrement, titre)
        {
            Mois = mois;
            Annee = annee;
        }
        public uint Mois{ get; set; }
        public uint Annee{ get; set; }

        public override string ToString()
        {
            return $"Titre : {Titre}, NumeroEnregistrement : {NumeroEnregistrement}, Mois : {Mois}, Annee : {Annee}";
        }

    }
}