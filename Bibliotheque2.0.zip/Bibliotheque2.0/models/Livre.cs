using System.Collections.Generic;

namespace LibraryManager.Models
{
    class Livre : Document
    {
        private uint _nbrP;
        private List<Auteur> _auteur  = new List<Auteur>();

        public Livre(int numeroEnregistrement, 
            string titre, 
            List<Auteur> auteur,
            uint nbrP) : base(numeroEnregistrement, titre)
            {
                _nbrP = nbrP;
                _auteur.AddRange(auteur);
            }

        public uint NbrP{ get; set;}
        public List<Auteur> Auteur() => _auteur;

        public string AddR()
        {
            string mList = "";
            foreach (var item in  Auteur())
            {
                mList += $"Prenom : {item.Prenom}, Nom : {item.Nom}";
            }
            return mList;
        }

        public override string ToString()
        {
            return $"Titre : {Titre}, NumeroEnregistrement : {NumeroEnregistrement}, Auteur : {AddR()}";
        }
    }
}