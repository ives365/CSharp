using System.Collections.Generic;
namespace LibraryManager.Models
{
    class Manuel : Livre
    {
        public Manuel(int numeroEnregistrement, 
            string titre, 
            List<Auteur> auteur,
            uint nbrP, 
            string niveau) : base(numeroEnregistrement, titre, auteur, nbrP)
            {
                Niveau = niveau;
            }

        public string Niveau{ get; set; }

         public override string ToString()
        {
            return $"Titre : {Titre}, NumeroEnregistrement : {NumeroEnregistrement}, Auteur : {AddR()}, Niveau : {Niveau}";
        }
    }
}