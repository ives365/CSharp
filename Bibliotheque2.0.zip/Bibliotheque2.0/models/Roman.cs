using System.Collections.Generic;
namespace LibraryManager.Models
{
    class Roman : Livre
    {
        public Roman(int numeroEnregistrement, 
            string titre, 
            List<Auteur> auteur,
            uint nbrP,
            uint prixLitt): base(numeroEnregistrement, titre, auteur, nbrP)
            {
                PrixLitt = prixLitt;

            }
        public uint PrixLitt{ get; set; }

        public override string ToString()
        {
            return $"Titre : {Titre}, NumeroEnregistrement : {NumeroEnregistrement}, Auteur : {AddR()}, PrixLitt : {PrixLitt}";
        }
    }
}