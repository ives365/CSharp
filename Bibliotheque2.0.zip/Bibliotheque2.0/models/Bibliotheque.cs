using System.Collections.Generic;
using LibraryManager.Tools;


namespace LibraryManager.Models
{
    class Bibliotheque
    {
        private uint _capacite;
        private List<Document> _document;

        public Bibliotheque(uint capacite)
        {
            _capacite = capacite;
            _document = new  List<Document>();
        }

        public uint Capacite =>  _capacite;

        public List<Document> Documents{
            get{ return _document; }
        }

         public Result DDocument(Document document)
        {
            /*if (document != null && _document.Count < _capacite)
            {
                 _document.Add(document);
                 return (true, "");
            }else
            {
                return (false, "");
            }*/

            if (document == null) return Result.Failure("Document null");
            if(_document.Count >= _capacite) return Result.Failure("Probleme de capacite");

            _document.Add(document);
            return Result.Ok();
            
        }

        public Document GetByNumeroEnregistrement(int numeroEnregistrement)
        {
            foreach (var item in _document)
            {
                if(item.NumeroEnregistrement == numeroEnregistrement) return item;
            }
             throw new  System.Exception("Document non trouvé");
        }

         public Result DeleteDoc(Document document)
        {
            if(document == null) return Result.Failure("Document null");
            _document.Remove(document);
            return Result.Ok();
        }


        
    }
}
