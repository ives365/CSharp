namespace LibraryManager.Models
{
    class Auteur
    {
        /*private string _nom;
        private string _prenom;*/

        public Auteur(string nom, string prenom)
        {
            Nom = nom;
            Prenom = prenom;
        }

        public string Nom{ get; set;}
        public string Prenom{ get; set; }
        
    }
    
}