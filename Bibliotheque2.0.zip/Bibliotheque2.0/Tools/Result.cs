namespace LibraryManager.Tools
{
    public class Result
    {

        private Result(bool success, string error="")
        {
            Error = error;
            Success = success;
        }
        public bool Success { get;}
        public string Error { get;}

        public static Result Ok()
        {
            return new Result(true);

        }

        public static Result Failure(string error)
        {
            return new Result(false, error);

        }
        
    }
    
}