﻿using System;
using System.Collections.Generic;
using  LibraryManager.Models;
using static System.Console;
using LibraryManager.Tools;


namespace Bibliotheque2._0
{
    class Program
    {
        static void Main(string[] args)
        {
            var bib =  CreateLibrary();
            var c = bib.Capacite;

            Add(bib);
            Display(bib.Documents);

            AddAvis(bib);
            
            
           
        
           // var document2 = new Livre(null);
            //document2.Auteur = t;
            //bib.DDocument(document);
           // var ok =  bib.DDocument(null);

            //var documents = bib.Documents;

             //Console.WriteLine(ok);
           // var bb = CreateLibrary();
            //Display(bb.Documents);
            
        }
        static void Add(Bibliotheque bb)
        {
             var document = new Document(1, "jfd");
            List<Auteur> t = new List<Auteur>();
            t.Add(new Auteur("ives","hugo"));
            t.Add(new Auteur("Diego","Pierre"));
            var document1 = new Document(3, "Vade mecum");
            bb.DDocument(document1);
            
            t.Add(new Auteur("Ives", "sss"));

            bb.DDocument(new Livre(1,
                 "Notre dame de Paris",
                t,
                586));
            bb.DDocument(new Revue(2, "Jeune Afrique", 12, 2019));
            bb.DDocument(new Dictionnaire(3, "Larousse de Poche", "Anglais" ));
            var b =  bb.DDocument(new Manuel(2, "Jeune Afrique", t, 587, "Niveau 1"));
             var result =  bb.DDocument(null);
             DisplayResult(b);
            

            /*var message = result.Success? "Success" : result.Error;
            WriteLine(message);*/

            void DisplayResult(Result r)
            {
                if (!r.Success)
                {
                WriteLine(r.Error);
                }
               else WriteLine("Success");
            }
        } 

        static Bibliotheque CreateLibrary()
        {
            var bib = new Bibliotheque(5);
            

            return bib;
        }

        static void Display(List<Document> documents)
        {
            foreach (var document in documents)
            {
                Console.WriteLine(document);
            }
        }

        static void AddAvis(Bibliotheque bibliotheque)
        {
            var document = bibliotheque.GetByNumeroEnregistrement(1);
            if(document != null) {
                document.AddAvis(new Avis("Urgent", "Pas interessant comme doc"));
                WriteLine(document);
        }}

        static void Menu()
        {
            int choix = 0;
            WriteLine();
            WriteLine();
            WriteLine();
        }
    }
}
