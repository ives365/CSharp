﻿using System;

namespace FichierXML
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
        static void SerializeElement(string filename)
        {
            
        }
    }
}
