﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Fichier
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            var course = new Course{
                Id = 1,
                Title = "Cool"
            };
            BinarySerialisation(course);
        }
        static void BinarySerialisation(Object obj)
        {
            IFormatter formater = new BinaryFormatter();
            Stream stream = new FileStream(@"Course.dat", FileMode.Create, FileAccess.Write);
            formater.Serialize(stream, obj);
        }
    }
    [Serializable]

    public class Course
    {
        public int Id{ get; set; }
        public string  Title{get; set; }
    }
}
