﻿using System;

namespace Tableau
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] voyelles = new char[6];
            voyelles[0] = 'a';
            voyelles[1] = 'e';
            voyelles[2] = 'i';
            voyelles[3] = 'o';
            voyelles[4] = 'u';
            voyelles[5] = 'y';

            /*for (int i = 0; i < voyelles.Length; i++)
            {
                Console.Write(voyelles[i]);
            }
            */
            // indice et range 
            Index last = ^1;
            char[] deux = voyelles[..2];
            char[] d2 = void[^2..];
            Console.WriteLine(voyelles[^1]);
        }
    }
}
